./hashcat64.bin -m 500 example500.hash example.dict
